package com.peisia.dto;
import lombok.Data;

@Data
public class GymDto {
	private Long bno;
	private String btext;
}
