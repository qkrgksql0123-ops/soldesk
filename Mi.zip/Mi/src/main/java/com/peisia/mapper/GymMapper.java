package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.GymDto;

public interface GymMapper {
	public ArrayList<GymDto> getList(int limitpage);
	public GymDto read(long bno);
	public void del(long bno);
	public void write(GymDto dto);
	public void update(GymDto dto);
	public int getTotalCount();
}
