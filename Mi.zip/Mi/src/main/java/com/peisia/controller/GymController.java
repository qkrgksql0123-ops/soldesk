package com.peisia.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.dto.GymDto;
import com.peisia.service.GymService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/gym/*")	//프로젝트 루트 경로 이하 /guest 상위폴더로 진입 시 여기로 진입하게 됨.  
@AllArgsConstructor	
@Controller

    public class GymController{
        private GymService service;
        
        @GetMapping("/getList")
        public String getList(@RequestParam(value="currentPage",defaultValue = "1")int currentPage,Model model) {
        	int totalcount = service.getTotalCount();
        	int pagesize = 5;
        	int totalpage = (totalcount + pagesize +1)/pagesize;
        	model.addAttribute("list",service.getList(currentPage));
        	model.addAttribute("totalPages", totalpage);
        	model.addAttribute("currentPage", currentPage); 
        	return "gym/getList";  // ⭕ redirect 빼라 해!

        }
        
    	
    @GetMapping({"/read","/update"})
    public void read(@RequestParam("bno")Long bno, Model model) {
    	model.addAttribute("read",service.read(bno));
    }
    
    @GetMapping("/del")
    public String del(@RequestParam("bno")Long bno) {
    	service.del(bno);
    	return "redirect:/gym/getList";
    }
    
    @PostMapping("/write")
    public String write(GymDto dto) {
    	service.write(dto);
    	return "redirect:/gym/getList";
    }
    
	@GetMapping("/write")	//get방식으로 페이지 넘겨주는 용도
	public void write() {
		
	}
	
	@PostMapping("/update")
	public String update(GymDto dto) {
		service.update(dto);
		return "redirect:/gym/getList";
	}
    }



