package com.peisia.movie.mapper;

import java.util.ArrayList;

import com.peisia.movie.dto.MovieDto;

public interface MovieMapper {
	public ArrayList<MovieDto> getList(int limitpage);
	public int getTotalCount();
}
