package com.peisia.movie.dto;

import lombok.Data;

@Data
public class MovieDto {
    private Long mno;              // 영화 번호
    private String title;          // 제목
    private String director;       // 감독
    private String actor;          // 배우
    private String genre;          // 장르
    private Double rating;         // 평점 (1.0 ~ 5.0)
    private Integer reviewCount;   // 리뷰 개수
}
