package com.peisia.movie.service;

import java.util.ArrayList;

import com.peisia.movie.dto.MovieDto;

public interface MovieService {
	public ArrayList<MovieDto> getList(int limitpage);
	public int getTotalCount();
}
