package com.peisia.movie.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.movie.dto.MovieDto;
import com.peisia.movie.mapper.MovieMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class MovieServicelmpl implements MovieService {
	@Setter(onMethod_ = @Autowired)
	private MovieMapper mapper;	
	
	@Override
	public ArrayList<MovieDto> getList(int currentpage){
		int limitpage = (currentpage-1)*5;
		return mapper.getList(limitpage);
	}
	@Override
	public int getTotalCount() {
		return mapper.getTotalCount();
	}
	@Override
	public MovieDto read(int mno) {
		return mapper.read(mno);
	}
	@Override
	public void del(int mno) {
		mapper.del(mno);
	}

}
