package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.dto.GymDto;
import com.peisia.mapper.GymMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class GymServicelmpl implements GymService{

	@Setter(onMethod_ = @Autowired)
	private GymMapper mapper;	
	
	@Override
	public ArrayList<GymDto> getList(int currentPage) {
		int limitpage = (currentPage -1)*5;
		return mapper.getList(limitpage);
	}
	@Override
	public GymDto read(long bno) {
		return mapper.read(bno);
	}
	
	@Override
	public void del(long bno) {
		mapper.del(bno);
	}
	
	@Override
	public void write(GymDto dto) {
		mapper.write(dto);
	}
	
	@Override
	public void update(GymDto dto) {
		mapper.update(dto);
	}
	
	@Override
	public int getTotalCount() {
		return mapper.getTotalCount();
	}
}
