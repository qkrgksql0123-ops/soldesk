package com.peisia.service;

import java.util.ArrayList;

import com.peisia.dto.GymDto;

public interface GymService {
	public ArrayList<GymDto> getList(int currentPage);
	public GymDto read(long bno);
	public void del(long bno); 
	public void write(GymDto dto);
	public void update(GymDto dto);
	public int getTotalCount();

}
