<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!-- 2. 0을 위한 준비. el 태그로 가져올 수 있는데 이걸 더 짧게 찍기위해 변수 대입함.     -->
<c:set var="cp" value="${pageContext.request.contextPath}" /><!-- el변수 cp에 경로저장 -->
   
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<table>
	<tr>
	<th>글번호</th>
	<th>제목</th>
	<th>감독</th>
	<th>배우</th>
	<th>별점</th>
	</tr>
	<tr>
	<td>${mno.mno }</td>
	<td>${mno.title }</td>
	<td>${mno.director }</td>
	<td>${mno.actor }</td>
	<td>${mno.rating }</td>
	</tr>
	
	<hr>
	<a href="${cp}/movie/del?mno=${mno.mno }">삭제하기</a>
	
</table>
</body>
</html>