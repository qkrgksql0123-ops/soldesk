<%@page import="java.util.ArrayList"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!-- 2. 0을 위한 준비. el 태그로 가져올 수 있는데 이걸 더 짧게 찍기위해 변수 대입함.     -->
<c:set var="cp" value="${pageContext.request.contextPath}" /><!-- el변수 cp에 경로저장 -->
        
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1>영화 보드!</h1>
<table>
    <tr>
        <th>번호</th>
        <th>제목</th>
        <th>감독</th>
        <th>배우</th>
        <th>장르</th>
        <th>평점</th>
    </tr>
    
    <c:forEach var="movie" items="${list}">
        <tr>
            <td>${movie.mno}</td>
         <td><a href="${cp}/movie/read?mno=${movie.mno}">${movie.title}</a></td>
            <td>${movie.director}</td>
            <td>${movie.actor}</td>
            <td>${movie.genre}</td>
            <td>${movie.rating}</td>
        </tr>
    </c:forEach>
</table>

<div class="pagination">
<c:forEach begin="1" end="${totalpage }" var="page">
	<c:if test="${page==currentpage }">
	<span>${page }</span>
	</c:if>
	<c:if test="${page != currentpage }">
	<a href="${cp }/movie/getList?currentpage=${page}">${page }</a>
	</c:if>
</c:forEach>
</div>

<a href="${cp }/movie/write">새 영화등록!</a>
</body>
</html>