<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<!-- 0. 웹 애플리케이션의 루트 경로(컨텍스트 경로) 를 가져와서 링크에 다 연결해줘야 함     -->
<!-- 1. 0을 위한 준비. jstl core 태그 선언     -->
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!-- 2. 0을 위한 준비. el 태그로 가져올 수 있는데 이걸 더 짧게 찍기위해 변수 대입함.     -->
<c:set var="cp" value="${pageContext.request.contextPath}" /><!-- el변수 cp에 경로저장 -->    
 
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>새글쓰기</title>
</head>
<body>
새 영화 등록!
<form action="${cp }/movie/write" method="post">
 <label>제목:</label>
    <input type="text" name="title" required>
    <br>
    
    <label>감독:</label>
    <input type="text" name="director" required>
    <br>
    
    <label>배우:</label>
    <input type="text" name="actor" required>
    <br>
    
    <label>장르:</label>
    <input type="text" name="genre" required>
    <br>
    
    <label>평점:</label>
    <input type="number" name="rating" step="0.1" min="0" max="5" required>
    <br>
    
    <button type="submit">등록하기</button>
</form>
</body>
</html>