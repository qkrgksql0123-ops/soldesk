package com.peisia.movie.mapper;

import java.util.ArrayList;

import com.peisia.movie.dto.MovieDto;

public interface MovieMapper {
	public ArrayList<MovieDto> getList(int limitpage);
	public int getTotalCount();
	public MovieDto read(int mno);
	public void del(int mno);
	public void write(MovieDto dto);
}
