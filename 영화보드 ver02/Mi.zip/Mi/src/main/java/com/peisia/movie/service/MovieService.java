package com.peisia.movie.service;

import java.util.ArrayList;

import com.peisia.movie.dto.MovieDto;

public interface MovieService {
	public ArrayList<MovieDto> getList(int limitpage);
	public int getTotalCount();
	public MovieDto read(int mno);
	public void del(int mno);
	public void write(MovieDto dto);
}
